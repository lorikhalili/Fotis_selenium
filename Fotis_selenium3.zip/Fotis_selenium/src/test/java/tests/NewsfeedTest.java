package tests;

import implementation.LoginImpl;
import implementation.NewsfeedImpl;
import org.testng.annotations.Test;

public class NewsfeedTest extends driver.WebDriver {

    @Test
    public void testContentPreview() {
        LoginImpl login = new LoginImpl(driver);
        login.login("rtregcode@beta.test", "Apprise1!");
        NewsfeedImpl preview = new NewsfeedImpl(driver);
        preview.openPost();
    }

    @Test
    public void testLikes() {
        LoginImpl login = new LoginImpl(driver);
        login.login("rtregcode@beta.test", "Apprise1!");
        NewsfeedImpl like = new NewsfeedImpl(driver);
        like.addLike();
    }

    @Test
    public void testComments() {
        LoginImpl login = new LoginImpl(driver);
        login.login("rtregcode@beta.test", "Apprise1!");
        NewsfeedImpl comment = new NewsfeedImpl(driver);
        comment.addComment();
    }

    @Test
    public void testShare() {
        LoginImpl login = new LoginImpl(driver);
        login.login("rtregcode@beta.test", "Apprise1!");
        NewsfeedImpl share = new NewsfeedImpl(driver);
        share.clickShare();
    }

}

package implementation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class NewsfeedImpl {
    private final By newsfeedContainer = By.xpath("//div[@class='sc-kImNAt imBpEr']");
    private final By openPostButton = By.xpath("//div[@class='css-1dbjc4n r-14lw9ot']");
    private final By closeButton = By.xpath("//body/div[@id='root']/div[@class='sc-hgYirE dLuAGi App']/div[@class='sc-cTcUcm leMhDo']/div[@class='sc-eyLAWx ifLcQs']/div[@class='sc-eqJLUj blmTEN content-preview']/div[@class='sc-bPxJiH fuZWdn']/div[@class='sc-yLwuU bwrHz']/div[@class='sc-cJRpLa hNwhDl']/div[1]/div[1]//*[name()='svg']//*[name()='path' and contains(@d,'M193.94 25')]");
    private final By likeButton = By.xpath("//div[@data-testid='64240adb77e9eb010400cab5_likeButton_icon']");
    private final By likeContainer = By.xpath("//div[@data-testid='64240adb77e9eb010400cab5_totalLikes']");
    private final By commentButton = By.xpath("//div[@data-cy='64240adb77e9eb010400cab5_commentButton_icon']");
    private final By commentInput = By.xpath("//div[@placeholder='Write a comment']");
    private final By add_commentButton = By.xpath("//div[@data-cy='64240adb77e9eb010400cab5_commentInput_button_text']");
    private final By commentContainer = By.xpath("//div[@data-cy='6425812ed641f100e65bcdff_comment_container']");
    private final By shareButton = By.xpath("//div[@data-cy='642aa17da0381501057afabf_shareButton_icon']");
    private final By shareText = By.xpath("//div[@data-testid='Text']");

    public final WebDriver driver;

    public NewsfeedImpl(WebDriver driver) {
        this.driver = driver;
    }

    public WebElement isNewsfeedDisplayed() { return driver.findElement(newsfeedContainer); }

    public void openPost() {
        driver.findElement(openPostButton).click();
        driver.findElement(closeButton).click();
        Assert.assertTrue(isNewsfeedDisplayed().isDisplayed());
        log.Logs.info("User can successfully open and close content preview");
    }

    public void addLike() {
        driver.findElement(likeButton).click();
        driver.findElement(likeContainer).isDisplayed();
        log.Logs.info("User can successfully add a like");
    }

    public void addComment() {
        driver.findElement(commentButton).click();
        driver.findElement(commentInput).sendKeys("Test Comment");
        driver.findElement(add_commentButton).click();
        driver.findElement(commentContainer).isDisplayed();
        log.Logs.info("User successfully added a comment");
    }

    public void clickShare() {
        driver.findElement(shareButton).click();
        driver.findElement(shareText).isDisplayed();
        log.Logs.info("User can successfully click share");
    }

}

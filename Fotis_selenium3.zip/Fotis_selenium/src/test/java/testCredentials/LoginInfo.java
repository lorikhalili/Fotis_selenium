package testCredentials;

public interface LoginInfo {
    String username = "test";
    String password = "test";

}
